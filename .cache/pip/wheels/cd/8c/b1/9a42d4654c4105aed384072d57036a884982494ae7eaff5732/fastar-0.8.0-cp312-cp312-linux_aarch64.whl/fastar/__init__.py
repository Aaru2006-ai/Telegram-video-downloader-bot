from .fastar import *

__doc__ = fastar.__doc__
if hasattr(fastar, "__all__"):
    __all__ = fastar.__all__